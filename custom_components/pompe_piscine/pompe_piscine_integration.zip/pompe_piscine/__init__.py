"""Intégration personnalisée pour la pompe de piscine."""
DOMAIN = "pompe_piscine"

async def async_setup(hass, config):
    return True
